<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hitung Total Pembelian</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        label, input, select {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
        }
        button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #45a049;
        }
        h3 {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Hitung Total Pembelian</h2>
    <form method="post" action="">
        <label for="totalPembelian">Total Pembelian (Rp):</label>
        <input type="number" id="totalPembelian" name="totalPembelian" required>

        <label for="isMember">Status Member:</label>
        <select id="isMember" name="isMember">
            <option value="true">Member</option>
            <option value="false">Non-Member</option>
        </select>

        <button type="submit" name="submit">Hitung</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        // Ambil input dari form
        $totalPembelian = $_POST['totalPembelian'];
        $isMember = $_POST['isMember'] == 'true';

        // Fungsi untuk menghitung total pembelian berdasarkan status member dan total pembelian
        function hitungTotalPembelian($totalPembelian, $isMember) {
            $diskon = 0;

            if ($isMember) {
                // Jika pembeli adalah member
                if ($totalPembelian >= 500000) {
                    $diskon = 0.1; // Diskon 10%
                } elseif ($totalPembelian >= 300000) {
                    $diskon = 0.05; // Diskon 5%
                }
            } else {
                // Jika pembeli bukan member
                if ($totalPembelian >= 500000) {
                    $diskon = 0.1; // Diskon 10% untuk non-member
                }
            }

            $potonganHarga = $totalPembelian * $diskon;
            $totalAkhir = $totalPembelian - $potonganHarga;

            return $totalAkhir;
        }

        // Hitung total akhir setelah diskon
        $totalAkhir = hitungTotalPembelian($totalPembelian, $isMember);
        
        // Tampilkan hasil
        echo "<h3>Total akhir setelah diskon: Rp " . number_format($totalAkhir, 0, ',', '.') . "</h3>";
    }
    ?>
</div>

</body>
</html>